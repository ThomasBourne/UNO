﻿using System;
using System.Collections.Generic;
using System.Text;

namespace uno
{
    public struct Player
    {
        List<string[]> deck;
        int deckLength;
        public void getValues(List<string[]> deck)
        {
            this.deck = deck;
            this.deckLength = deck.Count;
        }
        public List<string[]> Deck()
        {
            return deck;
        }
    }
    public class Store
    {

    }
    public class Deck
    {
        public string[] colours = { "Red", "Green", "Blue", "Yellow" };
        public string[] value = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "+2", "+4", "reverse", "miss" };
        public string[] GenerateCard()
        {
            Random rand = new Random();
            string val = value[rand.Next(0, value.Length - 1)];
            string colour = colours[rand.Next(0, colours.Length - 1)];
            string[] card = { val, colour };
            return card;
        }
        public List<string[]> GenerateStartupDeck()
        {
            List<string[]> deck = new List<string[]>();
            for (int i = 0; i < 7; i++)
            {
                deck.Add(GenerateCard());
            }
            return deck;
        }
    }
}
