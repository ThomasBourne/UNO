﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace uno
{
    class Run
    {
        static void Main(string[] args)
        {
            Deck deck = new Deck();
            Logic logic = new Logic();

            int numPlayers = NumPlayers();
            Console.WriteLine(numPlayers);

            string[] names = logic.CollectNames(numPlayers);

            System.Threading.Thread.Sleep(1000);
            Console.Clear();

            string[] pile = new string[1];
            pile = deck.GenerateCard();

            Player player1 = new Player();
            player1.getValues(deck.GenerateStartupDeck());
            Player player2 = new Player();
            player2.getValues(deck.GenerateStartupDeck());
            Player player3 = new Player();
            player3.getValues(deck.GenerateStartupDeck());
            Player player4 = new Player();
            player4.getValues(deck.GenerateStartupDeck());
            Player player5 = new Player();
            player5.getValues(deck.GenerateStartupDeck());
            Player player6 = new Player();
            player6.getValues(deck.GenerateStartupDeck());
            Player player7 = new Player();
            player7.getValues(deck.GenerateStartupDeck());

            List<Player> players = new List<Player>();
            for (int i = 0; i < numPlayers; i++)
            {
                if (i == 0)
                {
                    players.Add(player1);
                    players.Add(player2);
                }
                if (i == 2)
                    players.Add(player3);
                if (i == 3)
                    players.Add(player4);
                if (i == 4)
                    players.Add(player5);
                if (i == 5)
                    players.Add(player6);
                if (i == 6)
                    players.Add(player7);

            }
            while (true)
            {
                for (int i = 0; i < numPlayers; i++)
                {
                    logic.ShowDeck(players[i].Deck(), names[i], pile);
                    List<string[]> tmp = new List<string[]>();
                    (pile, tmp) = logic.Play(pile, players[i].Deck());
                    players[i].getValues(tmp);
                    System.Threading.Thread.Sleep(5000);
                }
            }
        }
        public static int NumPlayers()
        {
            int numPlayers;
            string strNumPlayers;
            Console.Write("Enter the number of players (2-7)\n>>> ");
            strNumPlayers = Console.ReadLine();
            while (strNumPlayers.Any(c => c < '2' || c > '7'))
            {
                Console.Write("Please enter a number between 2 and 7\n>>> ");
                strNumPlayers = Console.ReadLine();
                Console.Clear();
            }
            numPlayers = Convert.ToInt32(strNumPlayers);
            return numPlayers;
        }
    }
}